
A simple package to find the number of digits in the given number.

## How to install

```
pip install length
```

## How to use

Below example will help you

```
from length import length
l = 13412
length.nlength(l)	# returns the digit count in the given number

```



